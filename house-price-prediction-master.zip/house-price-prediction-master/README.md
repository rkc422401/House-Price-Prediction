# house-price-prediction
Predicting house prices using Linear Regression and Gradient Boosting Regressor

The tutorial and write up for the code can be found here 
https://medium.com/towards-data-science/create-a-model-to-predict-house-prices-using-python-d34fe8fad88f

Thank you
